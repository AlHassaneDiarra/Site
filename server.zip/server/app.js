const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const { connectToDB } = require("./db");
const productRoutes = require("./routes/productRoutes");

dotenv.config();
const app = express();
const PORT = process.env.PORT || 5001;

// Middlewares
app.use(express.json());
app.use(cors());

// Connexion à la base de données
connectToDB();

// Routes
app.use("/api/products", productRoutes);

// Test de l'API
app.get("/", (req, res) => {
  res.send("API e-commerce prête !");
});

// Démarrer le serveur
app.listen(PORT, () => {
  console.log(`✅ Backend actif sur http://localhost:${PORT}`);
});