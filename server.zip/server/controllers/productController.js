const { sql } = require("../db");

exports.getAllProducts = async (req, res) => {
  try {
    const result = await sql.query`SELECT * FROM Products`;
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.createProduct = async (req, res) => {
  const { name, price } = req.body;
  try {
    await sql.query`INSERT INTO Products (name, price) VALUES (${name}, ${price})`;
    res.status(201).json({ message: "Produit ajouté !" });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};